// src/app/kitchens/page.jsx

import { PROJECTS } from "@/components/portfolio/projectData";
import ProjectsMarquee from "@/components/portfolio/ProjectsMarquee";

const kitchenProjects = PROJECTS.filter((project) => project.category === "kitchen");

export default function KitchensPage() {
  return (
    <main>
      <ProjectsMarquee
        items={kitchenProjects.map((project) => ({
          title: project.title,
          href: `/projects/${project.slug}`,
          image: project.cardImage || project.heroImage,
        }))}
      />
    </main>
  );
}