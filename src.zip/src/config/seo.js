// src/config/seo.js

import { SITE } from "./site";

export const SEO_DEFAULTS = {
  title: SITE.name,
  description: SITE.description,
  image: SITE.images.og,
  type: "website",
  robots: "index,follow",
};

export const PAGE_SEO = {
  home: {
    path: "/",
    title:
      "Houston Kitchen & Bathroom Remodeling | Premier Kitchen & Bath | Since 1979",
    description:
      "Houston's most trusted kitchen and bathroom remodeling company since 1979. Premium craftsmanship, custom cabinetry, and beautiful results. Schedule a free consultation at our Houston showroom.",
    h1: "Houston Kitchen & Bathroom Remodeling Experts Since 1979",
    schemaType: "HomePage",
    keywords: [
      "houston kitchen bathroom remodeling",
      "kitchen remodeling houston",
      "bathroom remodeling houston tx",
      "houston remodeling company",
      "custom kitchen cabinets houston",
    ],
  },

  kitchens: {
    path: "/kitchens",
    title:
      "Kitchen Remodeling Houston TX | Custom Cabinets & Countertops | Premier Kitchen",
    description:
      "Premier Kitchen & Bath designs and builds custom kitchen remodels in Houston, TX. From cabinets and countertops to full layout redesigns. 45+ years of Houston craftsmanship.",
    h1: "Kitchen Remodeling in Houston, TX — Custom Cabinets & Countertops",
    schemaType: "Service",
    keywords: [
      "kitchen remodeling houston",
      "custom kitchen cabinets houston",
      "granite countertops houston",
      "quartz countertops houston",
      "houston kitchen contractor",
    ],
  },

  bathrooms: {
    path: "/bathrooms",
    title:
      "Bathroom Remodeling Houston TX | Walk-In Showers & Vanities | Premier Kitchen",
    description:
      "Transform your bathroom with Premier Kitchen & Bath. Walk-in showers, custom vanities, soaking tubs, and luxury tile work in Houston, TX. Trusted since 1979.",
    h1: "Bathroom Remodeling Houston — Walk-In Showers, Vanities & Tile",
    schemaType: "Service",
    keywords: [
      "bathroom remodeling houston tx",
      "walk in shower remodel houston",
      "custom bathroom vanity houston",
      "master bathroom remodel houston",
      "tile installation houston",
    ],
  },

  products: {
    path: "/products",
    title:
      "Kitchen & Bath Products Houston TX | Cabinets, Countertops, Tile & Fixtures | Premier Kitchen",
    description:
      "Explore kitchen and bath products at Premier Kitchen & Bath in Houston, including cabinetry, granite and quartz countertops, tile, fixtures, and finish selections for luxury remodels.",
    h1: "Kitchen & Bath Products in Houston, TX",
    schemaType: "CollectionPage",
    keywords: [
      "kitchen bath products houston",
      "custom kitchen cabinets houston",
      "granite countertops houston",
      "quartz countertops houston",
      "bath fixtures houston",
    ],
  },

  projects: {
    path: "/projects",
    title:
      "Kitchen & Bathroom Remodel Portfolio Houston | Premier Kitchen & Bath",
    description:
      "Browse completed kitchen and bathroom remodels by Premier Kitchen & Bath across Houston, TX. Custom luxury, modern, classic, and transitional projects.",
    h1: "Kitchen & Bathroom Remodel Portfolio in Houston",
    schemaType: "CollectionPage",
    keywords: [
      "kitchen remodel portfolio houston",
      "bathroom remodel portfolio houston",
      "houston remodeling projects",
      "custom kitchen houston",
      "bathroom renovation houston",
    ],
  },

  about: {
    path: "/about",
    title:
      "About Premier Kitchen & Bath | Houston Kitchen & Bathroom Remodeling Since 1979",
    description:
      "Learn more about Premier Kitchen & Bath, a Houston remodeling company trusted since 1979 for premium kitchen remodeling, bathroom remodeling, design guidance, and craftsmanship.",
    h1: "About Premier Kitchen & Bath",
    schemaType: "AboutPage",
    keywords: [
      "about premier kitchen bath",
      "houston remodeling company",
      "kitchen bathroom remodeling houston",
      "houston kitchen contractor",
      "bathroom remodeling houston",
    ],
  },

  reviews: {
    path: "/reviews",
    title:
      "Premier Kitchen & Bath Reviews | Houston Remodeling Client Feedback",
    description:
      "Read Premier Kitchen & Bath reviews from Houston-area homeowners. See client feedback on kitchen remodeling, bathroom remodeling, communication, craftsmanship, and finished results.",
    h1: "Premier Kitchen & Bath Reviews",
    schemaType: "ReviewPage",
    keywords: [
      "premier kitchen bath reviews",
      "houston remodeling reviews",
      "kitchen remodeling houston reviews",
      "bathroom remodeling houston reviews",
      "houston contractor reviews",
    ],
  },

  contact: {
    path: "/contact",
    title:
      "Contact Premier Kitchen & Bath | Houston Remodeling Consultations",
    description:
      "Schedule a kitchen or bathroom remodeling consultation with Premier Kitchen & Bath in Houston, TX. Visit our showroom or contact our team to begin your project.",
    h1: "Schedule a Consultation",
    schemaType: "ContactPage",
    keywords: [
      "contact premier kitchen bath",
      "houston remodeling consultation",
      "kitchen remodeling consultation houston",
      "bathroom remodeling consultation houston",
      "houston showroom consultation",
    ],
  },

  showroom: {
    path: "/showroom",
    title:
      "Kitchen & Bath Showroom Houston TX | 1918 Baker Rd | Premier Kitchen",
    description:
      "Visit Premier Kitchen & Bath's Houston showroom at 1918 Baker Rd. Explore cabinetry, countertops, tile, and fixture combinations in person. Open Monday-Saturday.",
    h1: "Visit Our Kitchen & Bath Showroom in Houston",
    schemaType: "LocalBusiness",
    keywords: [
      "kitchen bath showroom houston",
      "houston kitchen showroom",
      "houston bath showroom",
      "cabinetry countertops showroom houston",
      "premier kitchen bath showroom",
    ],
  },
};

export function getPageSeo(pageKey, overrides = {}) {
  const page = PAGE_SEO[pageKey] || {};

  return {
    ...SEO_DEFAULTS,
    ...page,
    ...overrides,
  };
}